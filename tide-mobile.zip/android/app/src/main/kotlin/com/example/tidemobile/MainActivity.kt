package com.example.tidemobile

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
